"""
Plot cluster outputs from cluster_speeches_2605.py.

Produces:
  output/Cluster_Sizes_2605_KMEANS.png          - overall size bar chart
  output/Cluster_Shares_by_Year_2605_KMEANS.png - per-cluster share of
                                                   year-total, faceted
  output/Cluster_Stacked_by_Year_2605_KMEANS.png - stacked-area shares
                                                    by year (sums to 1)
"""

import os
import math

import matplotlib.pyplot as plt
import pandas as pd

os.chdir('/Users/mathias/teaching_data_canada/')

CLUSTERED  = 'output/Speeches_clustered_2605.csv'
TOP_TERMS  = 'output/cluster_top_terms_2605.csv'
OUT_SIZES  = 'output/Cluster_Sizes_2605_KMEANS.png'
OUT_SHARE  = 'output/Cluster_Shares_by_Year_2605_KMEANS.png'
OUT_STACK  = 'output/Cluster_Stacked_by_Year_2605_KMEANS.png'

# ---------- load ----------
df = pd.read_csv(CLUSTERED, sep=';', usecols=['basepk', 'year', 'cluster'])
top = pd.read_csv(TOP_TERMS)

K = df['cluster'].nunique()
labels = {int(c): f"{c}: " + ' / '.join(top[str(c)].head(3).tolist())
          for c in top.columns}

# ---------- 1) overall cluster sizes ----------
sizes = df['cluster'].value_counts().sort_index()
shares = sizes / sizes.sum() * 100

fig, ax = plt.subplots(figsize=(11, 5))
ax.bar(sizes.index, sizes.values, color='steelblue', edgecolor='white')
ax.set_xticks(sizes.index)
ax.set_xticklabels([labels[c] for c in sizes.index],
                   rotation=35, ha='right', fontsize=9)
for c, n, p in zip(sizes.index, sizes.values, shares.values):
    ax.text(c, n, f'{p:.1f}%', ha='center', va='bottom', fontsize=8)
ax.set_ylabel('speeches')
ax.set_title(f'Cluster sizes (n = {len(df):,} speeches, '
             f'{df["year"].min()}–{df["year"].max()})')
for s in ('top', 'right'):
    ax.spines[s].set_visible(False)
plt.tight_layout()
plt.savefig(OUT_SIZES, dpi=200)
plt.close()
print(f'Wrote {OUT_SIZES}')

# ---------- 2) shares by year, faceted ----------
yr_cluster = (df.groupby(['year', 'cluster']).size()
                .rename('n').reset_index())
yr_total = df.groupby('year').size().rename('year_total')
yr_cluster = yr_cluster.merge(yr_total, on='year')
yr_cluster['share'] = yr_cluster['n'] / yr_cluster['year_total']

max_share = math.ceil(yr_cluster['share'].max() * 10) / 10
ncols = 5
nrows = math.ceil(K / ncols)
fig, axes = plt.subplots(nrows, ncols, figsize=(4*ncols, 2.8*nrows),
                         sharex=True, sharey=True)
axes = axes.flatten()

ymin, ymax = df['year'].min(), df['year'].max()
for c in range(K):
    sub = yr_cluster[yr_cluster['cluster'] == c].sort_values('year')
    ax = axes[c]
    ax.plot(sub['year'], sub['share'], color='steelblue', linewidth=1.5)
    ax.fill_between(sub['year'], 0, sub['share'], color='steelblue', alpha=0.15)
    ax.set_title(labels[c], fontsize=9)
    ax.set_xlim(ymin, ymax)
    ax.set_ylim(0, max_share)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    ax.tick_params(labelsize=8)

for ax in axes[K:]:
    ax.axis('off')

fig.suptitle('Cluster share of yearly speeches', fontsize=14)
plt.subplots_adjust(top=0.92, hspace=0.55, wspace=0.25)
plt.savefig(OUT_SHARE, dpi=200, bbox_inches='tight')
plt.close()
print(f'Wrote {OUT_SHARE}')

# ---------- 3) stacked-area shares by year ----------
# Wide pivot: rows = year, cols = cluster, values = share (sums to 1 per year)
share_wide = (yr_cluster.pivot(index='year', columns='cluster', values='share')
                         .fillna(0)
                         .sort_index())
# Order clusters by overall size (largest at bottom of stack, like the
# Gemini-category plot where "Other" sits at the bottom).
order = sizes.sort_values(ascending=False).index.tolist()
share_wide = share_wide[order]
ymin, ymax = share_wide.index.min(), share_wide.index.max()

fig, ax = plt.subplots(figsize=(13, 5.5))
ax.stackplot(share_wide.index, share_wide.values.T,
             labels=[labels[c] for c in order])
ax.set_xlim(ymin, ymax)
ax.set_ylim(0, 1)
ax.set_xlabel('year')
ax.set_ylabel('share')
ax.set_title(f'Share of speeches by cluster, by year ({ymin}–{ymax})')
ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=9, frameon=False)
plt.tight_layout()
plt.savefig(OUT_STACK, dpi=200, bbox_inches='tight')
plt.close()
print(f'Wrote {OUT_STACK}')
