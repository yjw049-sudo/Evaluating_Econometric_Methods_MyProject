"""
Inspect the Gemini speech-classification output.

Reads:
    output/speeches_classified.csv  (basepk, category, error)
    output/speeches_all_mps.csv     (MP metadata)
    input/Speeches*.xlsx            (raw text + ParlInfo maintopic)

Produces:
    - console: overall category distribution, cross-tab against ParlInfo
      maintopic, share by party.
    - output/category_share_by_year.png
    - output/category_share_by_party.png
    - prints 3 random speeches per category for spot-checking.

Run after classify_speeches_gemini.py.
"""

from __future__ import annotations

import random
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from classify_speeches_gemini import load_panel as load_panel_with_raw

ROOT = Path('/Users/mathias/teaching_data_canada')
CLASSIFIED = ROOT / 'output' / 'speeches_classified.csv'
RANDOM_SEED = 42


def load_panel() -> pd.DataFrame:
    if not CLASSIFIED.exists():
        sys.exit(f'{CLASSIFIED} not found. Run classify_speeches_gemini.py first.')
    cls = pd.read_csv(CLASSIFIED)
    cls = cls[cls['category'].notna() & (cls['category'] != '')].copy()
    panel = load_panel_with_raw()
    return cls.merge(panel, on='basepk')


def main():
    df = load_panel()
    print(f'Loaded {len(df):,} classified speeches\n')

    # ---------- overall ----------
    print('=== Overall category distribution ===')
    dist = df['category'].value_counts()
    dist_pct = (dist / len(df) * 100).round(1)
    print(pd.concat([dist, dist_pct.rename('pct')], axis=1).to_string())

    # ---------- cross-tab vs ParlInfo maintopic ----------
    print('\n=== Top 3 ParlInfo maintopics per Gemini category ===')
    for cat in sorted(df['category'].unique()):
        sub = df[df['category'] == cat]
        top = sub['maintopic'].dropna().value_counts().head(3)
        print(f'\n[{cat}]  ({len(sub):,} speeches)')
        for t, n in top.items():
            print(f'  {n:5d}  {t}')

    # ---------- by year ----------
    # Order categories by overall frequency so legend reads top-down
    cat_order = df['category'].value_counts().index.tolist()
    by_year = (df.groupby(['year', 'category']).size()
                 .unstack(fill_value=0)[cat_order])
    by_year_pct = by_year.div(by_year.sum(axis=1), axis=0)

    # (a) stacked-area share
    by_year_pct.plot(kind='area', stacked=True, figsize=(11, 5),
                     colormap='tab10')
    plt.title('Share of speeches by Gemini category, by year (1920-1949)')
    plt.ylabel('share'); plt.xlabel('year')
    plt.legend(loc='center left', bbox_to_anchor=(1.02, 0.5), fontsize=8)
    plt.tight_layout()
    out1 = ROOT / 'output' / 'category_share_by_year.png'
    plt.savefig(out1, dpi=120); plt.close()
    print(f'\nWrote {out1}')

    # (b) absolute counts as lines (makes the WWII wartime surge obvious)
    fig, ax = plt.subplots(figsize=(11, 5))
    cmap = plt.get_cmap('tab10')
    for i, cat in enumerate(cat_order):
        ax.plot(by_year.index, by_year[cat], label=cat, color=cmap(i),
                linewidth=1.8)
    # mark WWII period for context
    ax.axvspan(1939, 1945, color='grey', alpha=0.10)
    ax.text(1942, ax.get_ylim()[1] * 0.95, 'WWII', ha='center',
            va='top', fontsize=9, color='grey')
    ax.set_title('Number of speeches by Gemini category, by year (1920-1949)')
    ax.set_xlabel('year'); ax.set_ylabel('speeches')
    ax.legend(loc='center left', bbox_to_anchor=(1.02, 0.5), fontsize=8)
    plt.tight_layout()
    out1b = ROOT / 'output' / 'category_count_by_year.png'
    plt.savefig(out1b, dpi=120); plt.close()
    print(f'Wrote {out1b}')

    # ---------- by party ----------
    top_parties = df['party'].value_counts().head(5).index
    sub = df[df['party'].isin(top_parties)]
    by_party = (sub.groupby(['party', 'category']).size().unstack(fill_value=0))
    by_party_pct = by_party.div(by_party.sum(axis=1), axis=0)
    by_party_pct.plot(kind='bar', stacked=True, figsize=(10, 5), colormap='tab10')
    plt.title('Share of speeches by Gemini category, by party (top 5 parties)')
    plt.ylabel('share'); plt.xlabel('party')
    plt.xticks(rotation=20, ha='right')
    plt.legend(loc='center left', bbox_to_anchor=(1.02, 0.5), fontsize=8)
    plt.tight_layout()
    out2 = ROOT / 'output' / 'category_share_by_party.png'
    plt.savefig(out2, dpi=120); plt.close()
    print(f'Wrote {out2}')

    # ---------- spot-check: 3 random speeches per category ----------
    rng = random.Random(RANDOM_SEED)
    print('\n=== Spot-check: 3 random speeches per category ===')
    for cat in sorted(df['category'].unique()):
        sub = df[df['category'] == cat]
        n = min(3, len(sub))
        if n == 0:
            continue
        picks = sub.iloc[rng.sample(range(len(sub)), n)]
        print(f'\n--- {cat} ({len(sub):,} speeches) ---')
        for _, r in picks.iterrows():
            text = str(r['raw_speechtext'] or '').replace('\n', ' ')
            snippet = text[:280] + ('...' if len(text) > 280 else '')
            print(f'  [{r["year"]}] {r["speakername"]} ({r["party"]}) '
                  f'| ParlInfo: {r.get("maintopic")}')
            print(f'    {snippet}')


if __name__ == '__main__':
    main()
