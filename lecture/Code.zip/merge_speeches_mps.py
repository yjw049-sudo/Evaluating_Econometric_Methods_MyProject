"""
Merge MPs.csv biographical/political fields onto a speeches CSV.

Strategy: exact (name, year) join on a normalized name_join key; fuzzy
fallback via rapidfuzz on the residual; drop rows that match neither.

There is no shared numeric ID between the two sources, so we build a join key
by reformatting speakername ("First Middle Last") into the MPs.csv form
("Last, First Middle"), lowercased and accent-stripped. Honorifics and
trailing colons are stripped first.

CLI:
    python merge_speeches_mps.py            # defaults: speeches_all.csv -> speeches_all_mps.csv
    python merge_speeches_mps.py \
        --speeches output/speeches_1940_1_v2.csv \
        --output   final/speeches_MP_merged.csv
"""

import argparse
import os
import re
import time
import unicodedata

import numpy as np
import pandas as pd
from rapidfuzz import fuzz, process

os.chdir('/Users/mathias/teaching_data_canada/')
beg = time.time()

# ---------- defaults ----------
DEFAULT_SPEECHES = 'output/speeches_all.csv'
DEFAULT_MPS      = 'output/MPs.csv'
DEFAULT_OUTPUT   = 'output/speeches_all_mps.csv'

FUZZ_THRESHOLD = 88   # min WRatio score for an accepted fuzzy hit
FUZZ_MARGIN    = 5    # required margin over second-best candidate
SURNAME_MIN    = 85   # surname agreement required for a fuzzy hit

HONORIFICS = {'mr', 'mrs', 'ms', 'miss', 'hon', 'sir', 'dr',
              'mme', 'm', 'rt', 'right', 'lt', 'col', 'capt', 'maj', 'gen'}

MP_COLS = ['mp_id', 'mp_name', 'term_start', 'term_end',
           'riding', 'province', 'gender', 'party']

REQUIRED_SPEECH_COLS = ['basepk', 'speechtext', 'speakername', 'year']
OPTIONAL_SPEECH_COLS = ['speechdate', 'decade', 'step', 'pid']


def _try_unmojibake(s):
    """Recover UTF-8 read as Latin-1/Windows-1252 mojibake. No-op if not mojibaked.

    'Ã©' -> 'é'  (UTF-8 bytes read as Latin-1)
    'Ã‰' -> 'É'  (UTF-8 bytes read as Windows-1252; the high-byte 0x89 maps to '‰' in cp1252)
    cp1252 is a superset of Latin-1 for our purposes, so try it first.
    """
    for codec in ('cp1252', 'latin-1'):
        try:
            repaired = s.encode(codec).decode('utf-8')
            if repaired != s and '�' not in repaired:
                return repaired
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
    return s


def to_join_key(name):
    """Normalize a name to 'last, first middle' lowercased form."""
    if not isinstance(name, str) or not name.strip():
        return ''
    s = _try_unmojibake(name)
    s = s.strip().rstrip(':').strip()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    s = s.lower()
    s = re.sub(r"[^a-z\s,]", ' ', s)
    s = re.sub(r"\s+", ' ', s).strip()
    if not s:
        return ''

    if ',' in s:
        last, _, given = s.partition(',')
        last = last.strip()
        given_tokens = [t for t in given.split() if t not in HONORIFICS]
        return f"{last}, {' '.join(given_tokens)}".rstrip(', ').strip()

    tokens = [t for t in s.split() if t]
    while tokens and tokens[0] in HONORIFICS:
        tokens = tokens[1:]
    if not tokens:
        return ''
    if len(tokens) == 1:
        return tokens[0]
    return f"{tokens[-1]}, {' '.join(tokens[:-1])}"


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--speeches', default=DEFAULT_SPEECHES,
                   help=f'input speeches CSV (default: {DEFAULT_SPEECHES})')
    p.add_argument('--mps', default=DEFAULT_MPS,
                   help=f'MPs panel CSV (default: {DEFAULT_MPS})')
    p.add_argument('--output', default=DEFAULT_OUTPUT,
                   help=f'output CSV (default: {DEFAULT_OUTPUT})')
    return p.parse_args()


def main():
    args = parse_args()
    speeches_path = args.speeches
    mps_path = args.mps
    output_path = args.output

    print(f'Reading {speeches_path} and {mps_path}...')
    speeches = pd.read_csv(speeches_path, sep=';')
    mps = pd.read_csv(mps_path)

    missing = [c for c in REQUIRED_SPEECH_COLS if c not in speeches.columns]
    if missing:
        raise ValueError(f'speeches file missing required columns: {missing}')
    present_optional = [c for c in OPTIONAL_SPEECH_COLS if c in speeches.columns]

    speeches['year'] = speeches['year'].astype(int)
    mps['year'] = mps['year'].astype(int)
    n_total = len(speeches)
    print(f'  speeches: {n_total:,} rows | MPs: {len(mps):,} rows')
    print(f'  speech cols: required={REQUIRED_SPEECH_COLS} optional_present={present_optional}')

    # ---------- normalize names ----------
    speeches['name_join'] = speeches['speakername'].map(to_join_key)
    mps['name_join'] = mps['name'].map(to_join_key)
    mps = mps[mps['name_join'] != ''].copy()
    mps = mps.rename(columns={'name': 'mp_name'})

    # ---------- MPs uniqueness on (name_join, year) ----------
    grp = mps.groupby(['name_join', 'year']).size()
    n_dup_keys = (grp > 1).sum()
    if n_dup_keys:
        print(f'\n[mps] {n_dup_keys:,} (name_join, year) pairs have >1 row; '
              f'deduping by widest term tenure')
        mps['_ts'] = pd.to_datetime(mps['term_start'], errors='coerce')
        mps['_te'] = pd.to_datetime(mps['term_end'], errors='coerce')
        mps['_tenure'] = (mps['_te'] - mps['_ts']).dt.days
        mps = (mps.sort_values(['name_join', 'year', '_tenure'],
                               ascending=[True, True, False])
                  .drop_duplicates(['name_join', 'year'], keep='first')
                  .drop(columns=['_ts', '_te', '_tenure']))
    else:
        print('\n[mps] (name_join, year) is unique')

    # ---------- exact merge ----------
    merged = speeches.merge(
        mps[['name_join', 'year'] + MP_COLS],
        on=['name_join', 'year'], how='left', indicator='_m'
    )
    exact_mask = merged['_m'] == 'both'
    n_exact = int(exact_mask.sum())
    merged['match_type'] = np.where(exact_mask, 'exact', 'none')
    merged['match_score'] = np.nan
    merged = merged.drop(columns=['_m'])

    print(f'\n[exact merge] {n_exact:,} / {n_total:,} speeches matched '
          f'({n_exact / n_total * 100:.1f}%)')
    group_col = 'decade' if 'decade' in merged.columns else 'year'
    by_grp_exact = (merged.assign(_x=exact_mask.astype(int))
                          .groupby(group_col)
                          .agg(total=('_x', 'size'), exact=('_x', 'sum')))
    by_grp_exact['pct'] = (by_grp_exact['exact'] / by_grp_exact['total'] * 100).round(1)
    print(by_grp_exact.to_string())

    # ---------- fuzzy fallback ----------
    print('\n[fuzzy] scoring residual...')
    residual_keys = (merged.loc[merged['match_type'] == 'none',
                                ['name_join', 'year']]
                           .drop_duplicates()
                           .query('name_join != ""'))
    print(f'  unique unmatched (name_join, year) pairs: {len(residual_keys):,}')

    candidates_by_year = {
        yr: g['name_join'].tolist()
        for yr, g in mps.groupby('year')
    }
    cand_lookup_by_year = {
        yr: g.set_index('name_join')[MP_COLS]
        for yr, g in mps.groupby('year')
    }

    def surname_of(k):
        return k.split(',', 1)[0].strip()

    fuzzy_records = []
    for nj, yr in residual_keys.itertuples(index=False):
        cands = candidates_by_year.get(int(yr))
        if not cands:
            continue
        nj_sur = surname_of(nj)
        # restrict candidates to those whose surname is similar enough
        # (partial_ratio handles compound surnames like "saint laurent")
        cands_ok = [c for c in cands
                    if max(fuzz.ratio(nj_sur, surname_of(c)),
                           fuzz.partial_ratio(nj_sur, surname_of(c))) >= SURNAME_MIN]
        if not cands_ok:
            continue
        results = process.extract(nj, cands_ok, scorer=fuzz.WRatio, limit=2)
        if not results:
            continue
        best_name, best_score, _ = results[0]
        second_score = results[1][1] if len(results) > 1 else 0
        if best_score < FUZZ_THRESHOLD or (best_score - second_score) < FUZZ_MARGIN:
            continue
        mp_row = cand_lookup_by_year[int(yr)].loc[best_name]
        if isinstance(mp_row, pd.DataFrame):
            mp_row = mp_row.iloc[0]
        rec = {'name_join': nj, 'year': int(yr), 'match_score': best_score}
        for c in MP_COLS:
            rec[c] = mp_row[c]
        fuzzy_records.append(rec)

    fuzzy_df = pd.DataFrame(fuzzy_records)
    print(f'  fuzzy-accepted unique pairs: {len(fuzzy_df):,}')

    # ---------- apply fuzzy results to merged ----------
    if len(fuzzy_df):
        # left-merge fuzzy onto residual rows; replace MP cols where fuzzy hit
        residual_idx = merged.index[merged['match_type'] == 'none']
        sub = (merged.loc[residual_idx, ['name_join', 'year']]
                     .reset_index()
                     .merge(fuzzy_df, on=['name_join', 'year'], how='left'))
        hit_mask = sub['mp_id'].notna()
        sub = sub.loc[hit_mask]
        for c in MP_COLS:
            merged.loc[sub['index'].values, c] = sub[c].values
        merged.loc[sub['index'].values, 'match_score'] = sub['match_score'].values
        merged.loc[sub['index'].values, 'match_type'] = 'fuzzy'

    n_fuzzy = int((merged['match_type'] == 'fuzzy').sum())
    n_dropped = int((merged['match_type'] == 'none').sum())

    # ---------- report ----------
    print(f'\n[total] '
          f'exact: {n_exact:,} ({n_exact/n_total*100:.1f}%) | '
          f'fuzzy: {n_fuzzy:,} ({n_fuzzy/n_total*100:.1f}%) | '
          f'dropped: {n_dropped:,} ({n_dropped/n_total*100:.1f}%)')

    by_grp = (merged.groupby(group_col)
                    .agg(total=('match_type', 'size'),
                         exact=('match_type', lambda s: (s == 'exact').sum()),
                         fuzzy=('match_type', lambda s: (s == 'fuzzy').sum()),
                         dropped=('match_type', lambda s: (s == 'none').sum())))
    by_grp['exact_pct']   = (by_grp['exact']   / by_grp['total'] * 100).round(1)
    by_grp['fuzzy_pct']   = (by_grp['fuzzy']   / by_grp['total'] * 100).round(1)
    by_grp['dropped_pct'] = (by_grp['dropped'] / by_grp['total'] * 100).round(1)
    print(f'\n=== Coverage by {group_col} ===')
    print(by_grp.to_string())

    print('\n=== Top 20 dropped speakernames ===')
    dropped = merged[merged['match_type'] == 'none']
    print(dropped['speakername'].value_counts().head(20).to_string())

    print('\n=== Sample 10 fuzzy matches (deduped) ===')
    fuzzy_sample = (merged[merged['match_type'] == 'fuzzy']
                    [['speakername', 'year', 'mp_name', 'match_score']]
                    .drop_duplicates()
                    .head(10))
    print(fuzzy_sample.to_string())

    # ---------- write ----------
    out = merged[merged['match_type'] != 'none'].copy()
    output_schema = (REQUIRED_SPEECH_COLS + present_optional + MP_COLS
                     + ['match_type', 'match_score'])
    out = out[output_schema]
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    out.to_csv(output_path, index=False, sep=';')
    print(f'\nWrote {len(out):,} rows to {output_path}')
    print(f'Total time: {time.time() - beg:.1f}s')


if __name__ == '__main__':
    main()
