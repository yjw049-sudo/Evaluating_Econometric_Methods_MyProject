"""
Cluster ALL parliamentary speeches in input/Speeches*.xlsx into 10 KMeans
clusters on (1,2)-gram TF-IDF features.

Pipeline:
  1. Load all input/Speeches*.xlsx, drop topic headers/empty text, dedup,
     and drop speeches with <=100 words.
  2. Pass 1 (per speech): tokenize, lowercase, drop stopwords + banned
     list, keep only tokens with a synset in ALLOWED_POS (cheap WordNet
     pre-filter).
  3. Vocabulary pass: nltk.pos_tag on the unique surviving tokens (one
     call, not per sentence) — keep only NN*/JJ* (nouns + adjectives).
  4. Pass 2 (per speech): drop tokens not in the POS-tagged allowlist,
     Porter-stem the rest.
  5. TF-IDF, ngram_range=(1,2), min_df=5, max_df=0.5.
  6. MiniBatchKMeans, k=10 (full KMeans is wasteful at this scale).
  7. Write basepk, year, cluster, cleaned text to
     output/Speeches_clustered_2605.csv.

Run: python src/cluster_speeches_2605.py
"""

import gc
import glob
import os
import re
import time
from functools import lru_cache

import joblib
import nltk
import pandas as pd
from nltk.corpus import stopwords, wordnet
from nltk.stem import PorterStemmer
from nltk.tokenize import RegexpTokenizer
from sklearn.cluster import MiniBatchKMeans
from sklearn.feature_extraction.text import TfidfVectorizer

os.chdir('/Users/mathias/teaching_data_canada/')

# ---------- parameters ----------
K = 20
NGRAM = (1, 3)  # unigrams + bigrams + trigrams
MIN_DF = 10  # bumped from 5: ngram (2,3) explodes the feature space
MAX_DF = 0.5
MIN_TOKEN_LEN = 3
MIN_WORDS = 100  # drop speeches with <=100 whitespace-separated words
SEED = 0

# WordNet POS codes to keep:
#   'n' = noun, 'v' = verb, 'a' = adjective, 's' = satellite adjective
#   (group with 'a'), 'r' = adverb.
# Switch to {'n', 'v'} for nouns+verbs, {'n', 'a', 's', 'v'} for all
# content words, etc.
ALLOWED_POS = {'n', 'a', 's'}  # nouns + adjectives

INPUT_GLOB  = 'input/Speeches*.xlsx'
OUT_CSV     = 'output/Speeches_clustered_2605.csv'
OUT_VEC     = 'output/vectorizer_2605.sav'
OUT_MODEL   = 'output/kmeans_2605.sav'
OUT_TERMS   = 'output/cluster_top_terms_2605.csv'

BANNED = {
    'on', 'member', 'friend', 'mr', 'question', 'discuss', 'ask', 'want',
    'total', 'last', 'government', 'good', 'right', 'look', 'call', 'put',
    'could', 'made', 'make', 'take', 'give', 'go', 'get', 'may', 'there',
    # common procedural noise
    'hon', 'sir', 'madam', 'speaker', 'house', 'committee', 'order',
    'say', 'said', 'know', 'think', 'shall', 'would', 'one', 'two',
    # aggressive: content-free generics
    'time', 'times', 'year', 'years', 'day', 'days', 'matter', 'matters',
    'case', 'cases', 'fact', 'facts', 'point', 'points', 'sort', 'sorts',
    'kind', 'kinds', 'thing', 'things', 'way', 'ways', 'view', 'views',
    'opinion', 'opinions', 'regard', 'respect', 'reason', 'reasons',
    'occasion', 'occasions', 'instance', 'instances',
    # aggressive: words that defined the residual cluster
    'minister', 'ministers', 'people', 'peoples', 'work', 'works',
    'govern', 'government', 'governments', 'member', 'members',
}

# ---------- NLP setup ----------
for pkg in ('punkt', 'punkt_tab', 'stopwords', 'wordnet', 'omw-1.4',
            'averaged_perceptron_tagger', 'averaged_perceptron_tagger_eng'):
    try:
        nltk.data.find(pkg)
    except LookupError:
        nltk.download(pkg, quiet=True)

TOKEN_RE = RegexpTokenizer(r'[a-zA-Z]+')
STOP = set(stopwords.words('english')) | BANNED
STEM = PorterStemmer()


@lru_cache(maxsize=200_000)
def has_allowed_pos(token: str) -> bool:
    """True iff WordNet has any synset for the token with pos in ALLOWED_POS.

    Much faster than nltk.pos_tag per sentence — we trade syntactic precision
    for lexical class, which is what TF-IDF features actually consume.
    """
    syns = wordnet.synsets(token)
    if not syns:
        return False
    for s in syns:
        if s.pos() in ALLOWED_POS:
            return True
    return False


@lru_cache(maxsize=200_000)
def stem(token: str) -> str:
    return STEM.stem(token)


def survivors(text: str) -> list:
    """Pass 1: return list of unstemmed tokens that pass cheap filters.

    Drops short tokens, stopwords + banned list, and tokens with no
    WordNet synset in ALLOWED_POS. Does NOT stem (stemming happens after
    the vocabulary POS-tag pass so we tag real words, not stems).
    """
    if not isinstance(text, str):
        return []
    out = []
    for t in TOKEN_RE.tokenize(text.lower()):
        if len(t) < MIN_TOKEN_LEN:
            continue
        if t in STOP:
            continue
        if not has_allowed_pos(t):
            continue
        out.append(t)
    return out


def stems_from_tokens(tokens, allowed_unstemmed: set) -> str:
    """Pass 2: filter by post-POS-tag allowlist, then stem and space-join."""
    return ' '.join(stem(t) for t in tokens if t in allowed_unstemmed)


# ---------- load ----------
def load_all() -> pd.DataFrame:
    files = sorted(glob.glob(INPUT_GLOB))
    print(f'Loading {len(files)} xlsx files...')
    frames = []
    for f in files:
        t = time.time()
        df = pd.read_excel(
            f,
            usecols=['basepk', 'speechdate', 'speakerposition',
                     'speechtext', 'speakername'],
        )
        df = df[df['speechtext'].notna()]
        df = df[df['speakerposition'].fillna('') != 'topic']
        df = df[df['speakername'].notna()]
        # year from YYYY-MM-DD prefix
        df['year'] = (df['speechdate'].astype(str)
                                       .str.slice(0, 4)
                                       .where(lambda s: s.str.match(r'^\d{4}$'))
                                       .astype('Int64'))
        df = df.dropna(subset=['year'])
        df['year'] = df['year'].astype(int)
        df = df[['basepk', 'year', 'speechtext']]
        print(f'  {os.path.basename(f)}: {len(df):,} kept in {time.time()-t:.1f}s')
        frames.append(df)
    full = pd.concat(frames, ignore_index=True)
    full = full.drop_duplicates(subset=['speechtext'])
    print(f'Total kept after dedup: {len(full):,}')
    n_words = full['speechtext'].str.split().str.len()
    full = full[n_words > MIN_WORDS].reset_index(drop=True)
    print(f'After length filter (>{MIN_WORDS} words): {len(full):,}')
    return full


def main():
    beg = time.time()
    df = load_all()

    print('\nPass 1: tokenize + stopword/banned/WordNet filter...')
    t = time.time()
    df['tokens'] = df['speechtext'].map(survivors)
    df = df[df['tokens'].str.len() > 0].reset_index(drop=True)
    print(f'  pass-1 kept {len(df):,} non-empty in {time.time()-t:.1f}s')

    print('\nVocabulary POS-tag (nltk.pos_tag on unique tokens)...')
    t = time.time()
    vocab = set()
    for toks in df['tokens']:
        vocab.update(toks)
    vocab_list = sorted(vocab)
    print(f'  vocab size: {len(vocab_list):,}')
    tagged = nltk.pos_tag(vocab_list)
    # Keep nouns (NN*) and adjectives (JJ*). Drop the rest.
    KEEP_PREFIX = ('NN', 'JJ')
    allowed_unstemmed = {w for w, tag in tagged if tag.startswith(KEEP_PREFIX)}
    print(f'  kept after POS tag: {len(allowed_unstemmed):,} '
          f'({len(allowed_unstemmed)/len(vocab_list)*100:.1f}%)')
    print(f'  pos_tag in {time.time()-t:.1f}s')

    print('\nPass 2: filter + stem...')
    t = time.time()
    df['clean'] = df['tokens'].map(
        lambda toks: stems_from_tokens(toks, allowed_unstemmed)
    )
    df = df[df['clean'].str.len() > 0].reset_index(drop=True)
    df = df.drop(columns=['tokens'])
    print(f'  pass-2 kept {len(df):,} non-empty in {time.time()-t:.1f}s')

    print(f'\nVectorizing (TF-IDF, ngram={NGRAM})...')
    t = time.time()
    vec = TfidfVectorizer(
        ngram_range=NGRAM, min_df=MIN_DF, max_df=MAX_DF,
        token_pattern=r'\S+',  # tokens are already cleaned + space-joined
    )
    X = vec.fit_transform(df['clean'])
    print(f'  matrix: {X.shape[0]:,} docs x {X.shape[1]:,} features '
          f'in {time.time()-t:.1f}s')

    print(f'\nFitting MiniBatchKMeans (k={K})...')
    t = time.time()
    model = MiniBatchKMeans(
        n_clusters=K, random_state=SEED, batch_size=4096,
        max_iter=200, n_init=5, reassignment_ratio=0.01,
    )
    df['cluster'] = model.fit_predict(X)
    print(f'  fit in {time.time()-t:.1f}s | inertia={model.inertia_:.0f}')

    # top terms per cluster
    terms = vec.get_feature_names_out()
    order = model.cluster_centers_.argsort()[:, ::-1]
    top = pd.DataFrame(
        {k: [terms[i] for i in order[k, :15]] for k in range(K)}
    )
    top.to_csv(OUT_TERMS, index=False)
    print(f'\nTop terms per cluster (saved to {OUT_TERMS}):')
    print(top.to_string())

    # persist
    out = df[['basepk', 'year', 'cluster', 'clean']].rename(
        columns={'clean': 'speechtext_clean'}
    )
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    out.to_csv(OUT_CSV, index=False, sep=';')
    joblib.dump(vec, OUT_VEC)
    joblib.dump(model, OUT_MODEL)

    print(f'\nWrote {len(out):,} rows to {OUT_CSV}')
    print(f'Cluster sizes:\n{out["cluster"].value_counts().sort_index().to_string()}')
    print(f'\nTotal time: {time.time()-beg:.1f}s')

    del df, X
    gc.collect()


if __name__ == '__main__':
    main()
