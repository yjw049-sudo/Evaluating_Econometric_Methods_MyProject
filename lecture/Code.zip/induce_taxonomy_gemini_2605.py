"""
Stage 1 of the two-stage topic-categorisation pipeline.

Reads output/speeches_classified_2605.csv (free-text topic strings produced
by classify_speeches_gemini_2605.py), pulls the top N most frequent unique
topics, and asks Gemini to induce exactly 10 mutually exclusive, collectively
exhaustive categories with short definitions.

Output: output/topic_taxonomy_2605.json
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pandas as pd
from google import genai
from google.genai import types

ROOT = Path('/Users/mathias/teaching_data_canada')
INPUT_PATH = ROOT / 'output' / 'speeches_classified_2605.csv'
OUTPUT_PATH = ROOT / 'output' / 'topic_taxonomy_2605.json'

MODEL = 'gemini-2.5-pro'  # induction is one-shot, use the stronger model
TEMPERATURE = 0.0
TOP_N = 2000
N_CATEGORIES = 10


SYSTEM_INSTRUCTION = f"""\
You are a research assistant building a topical taxonomy for speeches in
the Canadian House of Commons, 1920-1949. You will be shown a list of
{TOP_N} short topic descriptions (one per line, with frequency counts),
each describing the subject of one or more parliamentary speeches.

Your task: propose EXACTLY {N_CATEGORIES} categories that, together,
cover the substantive variation in these topics. The categories must be:

- Mutually exclusive: every topic should fit clearly into one category.
- Collectively exhaustive: include a residual category if needed, but
  prefer substantive coverage over a large catch-all.
- Empirically grounded: derive the categories from what you see in the
  data, not from a generic political-science taxonomy.
- Stable across the 1920-1949 period: a category like "WWII conscription"
  is too narrow; "wartime policy" works.

For each category, write a one-sentence definition that another coder
could apply consistently. Include inclusion/exclusion guidance where
adjacent categories might otherwise be confused (e.g. tariffs-as-revenue
vs tariffs-as-trade-policy).

Return JSON in this exact shape:
{{
  "categories": [
    {{"name": "<short category name>", "definition": "<one sentence>"}},
    ...
  ]
}}
"""


RESPONSE_SCHEMA = {
    'type': 'object',
    'properties': {
        'categories': {
            'type': 'array',
            'minItems': N_CATEGORIES,
            'maxItems': N_CATEGORIES,
            'items': {
                'type': 'object',
                'properties': {
                    'name': {'type': 'string'},
                    'definition': {'type': 'string'},
                },
                'required': ['name', 'definition'],
            },
        },
    },
    'required': ['categories'],
}


def load_env(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, val = line.partition('=')
        os.environ.setdefault(key.strip(),
                              val.strip().strip('"').strip("'"))


def top_topics(path: Path, n: int) -> pd.Series:
    df = pd.read_csv(path)
    counts = df['topic'].value_counts()
    print(f'{len(df):,} speeches; {len(counts):,} unique topics')
    print(f'Top {n}: covers {counts.head(n).sum():,} speeches '
          f'({100 * counts.head(n).sum() / len(df):.1f}%)')
    return counts.head(n)


def build_prompt(counts: pd.Series) -> str:
    lines = [f'{c}\t{t}' for t, c in counts.items()]
    return ('Topic strings with frequency counts (count\\ttopic):\n\n'
            + '\n'.join(lines))


def main() -> None:
    load_env(ROOT / '.env')
    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key:
        sys.exit('GEMINI_API_KEY not set.')

    counts = top_topics(INPUT_PATH, TOP_N)
    prompt = build_prompt(counts)

    client = genai.Client(api_key=api_key)
    config = types.GenerateContentConfig(
        system_instruction=SYSTEM_INSTRUCTION,
        temperature=TEMPERATURE,
        response_mime_type='application/json',
        response_schema=RESPONSE_SCHEMA,
    )

    print(f'Calling {MODEL} with {len(counts):,} topics in prompt...')
    resp = client.models.generate_content(
        model=MODEL, contents=prompt, config=config,
    )
    taxonomy = json.loads(resp.text)

    cats = taxonomy['categories']
    if len(cats) != N_CATEGORIES:
        sys.exit(f'Expected {N_CATEGORIES} categories, got {len(cats)}')

    with open(OUTPUT_PATH, 'w') as f:
        json.dump(taxonomy, f, indent=2)
    print(f'Wrote {OUTPUT_PATH}')
    print()
    for i, c in enumerate(cats, 1):
        print(f'{i:2d}. {c["name"]}')
        print(f'    {c["definition"]}')


if __name__ == '__main__':
    main()
