"""
Classify Canadian parliamentary speeches into 10 topical categories with
Gemini 2.0 Flash.

Pipeline
--------
1. Load output/speeches_all_mps.csv (MP-joined panel, stemmed text only).
2. Recover the *raw* speech text and ParlInfo topic hints from
   input/Speeches*.xlsx via basepk.
3. For each speech, call Gemini with a structured-output schema enforcing
   exactly one of ten categories.
4. Append results to output/speeches_classified.csv as we go. Re-running
   the script skips basepks already classified, so Ctrl-C is safe.

Usage
-----
    python src/classify_speeches_gemini.py --sample 500    # stratified pilot
    python src/classify_speeches_gemini.py --limit 20      # quick smoke test
    python src/classify_speeches_gemini.py                 # full run (~162k)

Requires GEMINI_API_KEY in .env (Google AI Studio key).
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import enum
import glob
import os
import random
import re
import sys
import time
from pathlib import Path

import pandas as pd
from google import genai
from google.genai import types

# ---------- paths and config ----------
ROOT = Path('/Users/mathias/teaching_data_canada')
SPEECHES_MPS_PATH = ROOT / 'output' / 'speeches_all_mps.csv'
INPUT_GLOB = str(ROOT / 'input' / 'Speeches*.xlsx')
OUTPUT_PATH = ROOT / 'output' / 'speeches_classified.csv'
MERGED_CACHE = ROOT / 'output' / 'speeches_with_raw.parquet'

MODEL = 'gemini-flash-lite-latest'  # 2.0-flash-lite is closed to new users
TEMPERATURE = 0.0
MAX_CHARS = 6000          # raw speech truncation (p99 is ~2,700)
DEFAULT_CONCURRENCY = 80  # ~0.6s latency * 80 ≈ 135 RPS ≈ 8000 RPM
FLUSH_EVERY = 500         # write to disk after this many new results
RANDOM_SEED = 42
MAX_RETRIES = 6
RATE_LIMIT_SIGNALS = ('429', 'RESOURCE_EXHAUSTED', 'quota', 'rate limit',
                      'rate_limit', 'Too Many Requests')


# ---------- the ten categories ----------
class Category(str, enum.Enum):
    WARTIME = 'Wartime'
    INFRASTRUCTURE = 'Infrastructure'
    HEALTH_CARE = 'Health care'
    EDUCATION = 'Education'
    INCOME_AND_TAX = 'Income and Tax'
    INTERNATIONAL_RELATIONS = 'International relations'
    BUDGET = 'Budget'
    TRADE = 'Trade'
    IMMIGRATION = 'Immigration'
    OTHER = 'Other'


SYSTEM_INSTRUCTION = """\
You are a research assistant classifying speeches from the Canadian House
of Commons, 1920-1949. Read the speech and assign exactly ONE category
from this list:

- Wartime: WWI aftermath/veterans/pensions, WWII conduct/conscription/munitions/
  war finance, early Cold War defence and demobilisation.
- Infrastructure: railways, roads, ports, postal service, telegraph, public
  works, hydro/power, broadcasting infrastructure.
- Health care: public health, quarantine, hospitals, military medical,
  pensions for disability/illness, drug policy.
- Education: schools, universities, research grants, vocational training,
  residential schools.
- Income and Tax: income tax, excise, sales tax, customs duties as REVENUE,
  corporate tax, tax exemptions. (Tariffs as TRADE POLICY go under Trade.)
- International relations: treaties, League of Nations, UN, Commonwealth,
  diplomacy, embassies, foreign policy not centred on war.
- Budget: annual budget, supply, estimates, public debt, deficit, government
  spending overall. (Specific tax measures go under Income and Tax.)
- Trade: tariffs as trade policy, imperial preference, trade agreements,
  marketing boards, Wheat Board, export/import regulation.
- Immigration: immigration policy, refugees, displaced persons, citizenship,
  deportation, naturalisation.
- Other: anything that does not clearly fit the above (procedural motions,
  agriculture-not-trade, labour relations, indigenous affairs outside
  residential schools, constitutional questions, etc.).

Pick the SINGLE best fit. Use "Other" only if no listed category is a
reasonable match. Ignore procedural openings ("Mr. Speaker, ...") and
classify by the substantive topic the speaker addresses. When a speech
spans several categories, pick the one with the most content."""


PROMPT_TEMPLATE = """\
Year: {year}
Speaker: {speakername} ({party}, {riding}, {province})
ParlInfo topic: {topic_hint}

Speech:
{speechtext}
"""


# ---------- env loading (no python-dotenv dependency) ----------
def load_env(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, val = line.partition('=')
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        os.environ.setdefault(key, val)


# ---------- data loading ----------
def build_merged_panel() -> pd.DataFrame:
    """Join speeches_all_mps.csv (MP metadata, stemmed text discarded) with
    the raw xlsx files (raw text + ParlInfo topic columns)."""
    print(f'Loading {SPEECHES_MPS_PATH.name}...')
    mps = pd.read_csv(SPEECHES_MPS_PATH, sep=';',
                      usecols=['basepk', 'speakername', 'speechdate', 'year',
                               'mp_name', 'riding', 'province', 'party'])
    print(f'  {len(mps):,} MP-joined speeches')

    print(f'Loading raw xlsx files from {INPUT_GLOB}...')
    raw_frames = []
    for path in sorted(glob.glob(INPUT_GLOB)):
        df = pd.read_excel(
            path,
            usecols=['basepk', 'speechtext', 'maintopic',
                     'subtopic', 'subsubtopic'],
        )
        df = df.rename(columns={'speechtext': 'raw_speechtext'})
        raw_frames.append(df)
        print(f'  {os.path.basename(path)}: {len(df):,} rows')
    raw = pd.concat(raw_frames, ignore_index=True)
    raw = raw.drop_duplicates(subset=['basepk'], keep='first')
    print(f'  {len(raw):,} unique raw speeches')

    merged = mps.merge(raw, on='basepk', how='inner')
    print(f'Merged: {len(merged):,} speeches with raw text')
    return merged


def load_panel(rebuild_cache: bool = False) -> pd.DataFrame:
    """Load the MP-joined panel with raw text. Caches the merged frame as
    parquet on first run; subsequent runs read the cache in ~1s instead of
    re-reading the 12 xlsx files (~30s)."""
    if MERGED_CACHE.exists() and not rebuild_cache:
        print(f'Loading cached panel from {MERGED_CACHE.name}...')
        df = pd.read_parquet(MERGED_CACHE)
        print(f'  {len(df):,} speeches')
        return df
    df = build_merged_panel()
    print(f'Caching panel to {MERGED_CACHE.name}...')
    df.to_parquet(MERGED_CACHE, index=False)
    return df


def topic_hint(row) -> str:
    parts = [row.get('maintopic'), row.get('subtopic'), row.get('subsubtopic')]
    parts = [str(p).strip() for p in parts if isinstance(p, str) and p.strip()]
    return ' > '.join(parts) if parts else '(none)'


def build_prompt(row) -> str:
    text = str(row.get('raw_speechtext') or '')
    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS] + ' [...truncated]'
    return PROMPT_TEMPLATE.format(
        year=row.get('year'),
        speakername=row.get('speakername') or '(unknown)',
        party=row.get('party') or '(unknown party)',
        riding=row.get('riding') or '(unknown riding)',
        province=row.get('province') or '(unknown province)',
        topic_hint=topic_hint(row),
        speechtext=text,
    )


# ---------- Gemini call ----------
GEN_CONFIG = types.GenerateContentConfig(
    system_instruction=SYSTEM_INSTRUCTION,
    temperature=TEMPERATURE,
    response_mime_type='text/x.enum',
    response_schema=Category,
)


def _is_rate_limit(err: BaseException) -> bool:
    msg = str(err)
    return any(s in msg for s in RATE_LIMIT_SIGNALS)


async def classify_one(client: genai.Client, row,
                       sem: asyncio.Semaphore) -> dict:
    prompt = build_prompt(row)
    for attempt in range(MAX_RETRIES):
        async with sem:
            try:
                resp = await client.aio.models.generate_content(
                    model=MODEL, contents=prompt, config=GEN_CONFIG,
                )
                label = (resp.text or '').strip()
                if label not in {c.value for c in Category}:
                    label = Category.OTHER.value
                return {'basepk': int(row['basepk']),
                        'category': label, 'error': ''}
            except Exception as e:
                if attempt == MAX_RETRIES - 1:
                    return {'basepk': int(row['basepk']),
                            'category': '',
                            'error': f'{type(e).__name__}: {e}'[:300]}
                # Rate-limit: long backoff with jitter (30s, 60s, 120s, ...)
                # Other errors: short exponential (1s, 2s, 4s, ...)
                if _is_rate_limit(e):
                    delay = 30.0 * (2 ** attempt)
                else:
                    delay = 1.0 * (2 ** attempt)
        delay += random.uniform(0, 0.5 * delay)
        await asyncio.sleep(delay)
    return {'basepk': int(row['basepk']), 'category': '', 'error': 'unreachable'}


# ---------- output management ----------
OUT_FIELDS = ['basepk', 'category', 'error']


def load_done(path: Path) -> set[int]:
    if not path.exists():
        return set()
    done = pd.read_csv(path)['basepk'].astype(int)
    return set(done.tolist())


def append_rows(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    new_file = not path.exists()
    with open(path, 'a', newline='') as f:
        w = csv.DictWriter(f, fieldnames=OUT_FIELDS)
        if new_file:
            w.writeheader()
        w.writerows(rows)


# ---------- sampling ----------
def stratified_by_year(df: pd.DataFrame, n: int) -> pd.DataFrame:
    rng = random.Random(RANDOM_SEED)
    years = sorted(df['year'].unique())
    per_year = max(1, n // len(years))
    parts = []
    for y in years:
        sub = df[df['year'] == y]
        k = min(per_year, len(sub))
        idx = rng.sample(range(len(sub)), k)
        parts.append(sub.iloc[idx])
    out = pd.concat(parts, ignore_index=True)
    if len(out) > n:
        out = out.sample(n, random_state=RANDOM_SEED).reset_index(drop=True)
    return out


# ---------- main ----------
async def classify_all(df: pd.DataFrame, out_path: Path,
                       concurrency: int) -> None:
    done = load_done(out_path)
    if done:
        print(f'Resuming: {len(done):,} basepks already in {out_path.name}')
    df = df[~df['basepk'].astype(int).isin(done)].reset_index(drop=True)
    if df.empty:
        print('Nothing to do.')
        return

    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key:
        sys.exit('GEMINI_API_KEY not set. Add it to .env at the repo root.')
    client = genai.Client(api_key=api_key)
    sem = asyncio.Semaphore(concurrency)

    total = len(df)
    print(f'Classifying {total:,} speeches '
          f'(concurrency={concurrency}, model={MODEL})')
    start = time.time()
    buffer: list[dict] = []
    n_done = 0

    rows_iter = (df.iloc[i] for i in range(total))
    tasks = [asyncio.create_task(classify_one(client, r, sem)) for r in rows_iter]

    for coro in asyncio.as_completed(tasks):
        res = await coro
        buffer.append(res)
        n_done += 1
        if len(buffer) >= FLUSH_EVERY:
            append_rows(out_path, buffer)
            buffer.clear()
            rate = n_done / (time.time() - start)
            eta = (total - n_done) / rate if rate else 0
            print(f'  {n_done:,}/{total:,}  '
                  f'rate={rate:.1f}/s  eta={eta/60:.1f}m')

    append_rows(out_path, buffer)
    elapsed = time.time() - start
    print(f'Done. {n_done:,} classified in {elapsed/60:.1f}m '
          f'({n_done/elapsed:.1f}/s). Output -> {out_path}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sample', type=int, default=None,
                    help='stratified-by-year sample size (pilot)')
    ap.add_argument('--limit', type=int, default=None,
                    help='hard row cap (smoke testing)')
    ap.add_argument('--rebuild-cache', action='store_true',
                    help='ignore the parquet cache and rebuild from xlsx')
    ap.add_argument('--concurrency', type=int, default=DEFAULT_CONCURRENCY,
                    help='in-flight API requests (default %(default)s; '
                         'paid tier-1 flash-lite tolerates ~50, tier-2 ~150)')
    args = ap.parse_args()

    load_env(ROOT / '.env')
    df = load_panel(rebuild_cache=args.rebuild_cache)

    if args.sample is not None:
        df = stratified_by_year(df, args.sample)
        print(f'Stratified sample: {len(df):,} speeches across '
              f'{df["year"].nunique()} years')
    if args.limit is not None:
        df = df.head(args.limit).copy()
        print(f'Limit applied: {len(df):,} speeches')

    asyncio.run(classify_all(df, OUTPUT_PATH, args.concurrency))


if __name__ == '__main__':
    main()
