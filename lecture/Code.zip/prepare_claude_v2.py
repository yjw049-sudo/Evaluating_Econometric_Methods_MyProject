"""
Prepare parliamentary speeches for the k-means pipeline in 3_Model_Speech.py.

Loops over every input/Speeches{decade}_{step}.xlsx file, filters by word
count, cleans the text (lowercase, tokenize on letters, drop stopwords,
Porter-stem), and writes a single combined output/speeches_all.csv with ';'
delimiter.

Per-file: drop NA on speakername/speechtext/speechdate, dedupe by speechtext,
word-count filter on raw text, clean. No global cross-file dedup.

Output schema: basepk, speechtext, speakername, speechdate, year, decade, step, pid.
`pid` is the raw-xlsx UUID identifier for the speaker (~87% populated) and is
retained for downstream MP joining via merge_speeches_mps.py.
"""

import glob
import os
import re
import time

import nltk
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from tqdm import tqdm

os.chdir('/Users/mathias/teaching_data_canada/')
beg = time.time()

# ---------- parameters ----------
input_glob  = 'input/Speeches*.xlsx'
output_path = 'output/speeches_all.csv'
lower_words = 100    # inclusive lower bound on raw speech length (words)
upper_words = 1000   # inclusive upper bound on raw speech length (words)
extra_stopwords = {'canada', 'hon', 'member', 'question', 'ask',
                   'govern', 'minist'}

FILENAME_RE = re.compile(r'Speeches(\d{4})_(\d+)\.xlsx$')

# ---------- one-time setup ----------
try:
    stopwords.words('english')
except LookupError:
    nltk.download('stopwords', quiet=True)

TOKEN_RE  = re.compile(r'[a-zA-Z]+')
STEMMER   = PorterStemmer()
STOPWORDS = set(stopwords.words('english')) | extra_stopwords
_stem_cache: dict[str, str] = {}


def clean_text(text):
    if not isinstance(text, str):
        return ''
    out = []
    for tok in TOKEN_RE.findall(text.lower()):
        if tok in STOPWORDS:
            continue
        stem = _stem_cache.get(tok)
        if stem is None:
            stem = STEMMER.stem(tok)
            _stem_cache[tok] = stem
        if stem not in STOPWORDS:
            out.append(stem)
    return ' '.join(out)


# ---------- loop over input files ----------
files = sorted(glob.glob(input_glob))
assert files, f'No files matched {input_glob}'
print(f'Found {len(files)} input files')

frames = []
required = {'basepk', 'speechtext', 'speakername', 'speechdate', 'pid'}

for path in files:
    m = FILENAME_RE.search(path)
    assert m, f'Unexpected filename: {path}'
    file_decade, step = int(m.group(1)), int(m.group(2))

    print(f'\n[{os.path.basename(path)}] decade={file_decade} step={step}')
    df = pd.read_excel(path)

    missing = required - set(df.columns)
    assert not missing, f'Missing columns in {path}: {missing}'

    df = df.dropna(subset=['speakername', 'speechtext', 'speechdate'])
    df = df.drop_duplicates(subset=['speechtext']).reset_index(drop=True)
    n_before = len(df)

    df['wordcount'] = df['speechtext'].astype(str).str.split().str.len()
    df = df.loc[df['wordcount'].between(lower_words, upper_words, inclusive='both')].copy()
    print(f'  word filter [{lower_words}, {upper_words}]: kept {len(df):,} of {n_before:,} '
          f'(mean: {df["wordcount"].mean():.0f} words)' if len(df) else
          f'  word filter [{lower_words}, {upper_words}]: kept 0 of {n_before:,}')

    if len(df) == 0:
        continue

    df['speechdate'] = df['speechdate'].astype(str)
    df['year']   = df['speechdate'].str[:4]
    df['decade'] = (df['year'].astype(int) // 10 * 10)
    df['step']   = step

    df['speechtext'] = [clean_text(t) for t in tqdm(df['speechtext'],
                                                    desc=f'  Cleaning {file_decade}_{step}')]
    df = df[df['speechtext'].str.len() > 0]
    df = df[['basepk', 'speechtext', 'speakername', 'speechdate',
             'year', 'decade', 'step', 'pid']]
    frames.append(df)
    print(f'  kept {len(df):,} cleaned speeches')

# ---------- write combined ----------
out = pd.concat(frames, ignore_index=True)
os.makedirs('output', exist_ok=True)
out.to_csv(output_path, index=False, sep=';')
print(f'\nWrote {len(out):,} cleaned speeches to {output_path}')
print(f'Total time: {time.time() - beg:.1f}s')
