"""
Stage 2 of the two-stage topic-categorisation pipeline.

Reads the induced taxonomy (output/topic_taxonomy_2605.json) and the
free-text topics from output/speeches_classified_2605.csv. For each
UNIQUE topic string, asks Gemini to assign one of the 10 category names.

Batches ~BATCH_SIZE topics per API call to keep cost and latency low.
Appends to output/topic_to_category_2605.csv as it goes; resumable.

Usage
-----
    python src/assign_categories_gemini_2605.py --limit 200    # smoke test
    python src/assign_categories_gemini_2605.py                # full run
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import os
import random
import sys
import time
from pathlib import Path

import pandas as pd
from google import genai
from google.genai import types

ROOT = Path('/Users/mathias/teaching_data_canada')
TOPICS_PATH = ROOT / 'output' / 'speeches_classified_2605.csv'
TAXONOMY_PATH = ROOT / 'output' / 'topic_taxonomy_2605.json'
OUTPUT_PATH = ROOT / 'output' / 'topic_to_category_2605.csv'

MODEL = 'gemini-flash-lite-latest'
TEMPERATURE = 0.0
BATCH_SIZE = 50
DEFAULT_CONCURRENCY = 40
FLUSH_EVERY = 20  # batches
MAX_RETRIES = 6
RATE_LIMIT_SIGNALS = ('429', 'RESOURCE_EXHAUSTED', 'quota', 'rate limit',
                      'rate_limit', 'Too Many Requests')


def load_env(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, val = line.partition('=')
        os.environ.setdefault(key.strip(),
                              val.strip().strip('"').strip("'"))


def load_taxonomy() -> tuple[list[str], str]:
    tax = json.loads(TAXONOMY_PATH.read_text())
    names = [c['name'] for c in tax['categories']]
    lines = [f'- {c["name"]}: {c["definition"]}' for c in tax['categories']]
    body = '\n'.join(lines)
    instr = f"""\
You are a research assistant labelling topical descriptions of speeches in
the Canadian House of Commons, 1920-1949. Each input item is a short noun
phrase describing one speech's topic. Assign EXACTLY ONE category from
the list below to each item.

Categories:
{body}

Pick the SINGLE best fit. If a topic touches several categories, choose
the one with the most substantive content. Use the residual category
only when no listed category is a reasonable match.

You will receive a JSON array of topic strings. Return a JSON array of
the same length where each element is the chosen category name (exact
string from the list above). Preserve the input order. Do not return
anything else."""
    return names, instr


def load_done() -> set[str]:
    if not OUTPUT_PATH.exists():
        return set()
    df = pd.read_csv(OUTPUT_PATH)
    return set(df['topic'].astype(str).tolist())


def append_rows(rows: list[dict]) -> None:
    if not rows:
        return
    new_file = not OUTPUT_PATH.exists()
    with open(OUTPUT_PATH, 'a', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['topic', 'category'])
        if new_file:
            w.writeheader()
        w.writerows(rows)


def _is_rate_limit(err: BaseException) -> bool:
    msg = str(err)
    return any(s in msg for s in RATE_LIMIT_SIGNALS)


async def classify_batch(client: genai.Client, batch: list[str],
                         category_set: set[str], config,
                         sem: asyncio.Semaphore) -> list[dict]:
    prompt = json.dumps(batch, ensure_ascii=False)
    for attempt in range(MAX_RETRIES):
        async with sem:
            try:
                resp = await client.aio.models.generate_content(
                    model=MODEL, contents=prompt, config=config,
                )
                labels = json.loads(resp.text)
                if not isinstance(labels, list) or len(labels) != len(batch):
                    raise ValueError(f'expected list of {len(batch)}, '
                                     f'got {type(labels).__name__} '
                                     f'len={len(labels) if isinstance(labels, list) else "n/a"}')
                rows = []
                fallback = next(iter(category_set))
                for topic, lab in zip(batch, labels):
                    if lab not in category_set:
                        lab = fallback
                    rows.append({'topic': topic, 'category': lab})
                return rows
            except Exception as e:
                if attempt == MAX_RETRIES - 1:
                    return [{'topic': t, 'category': ''} for t in batch]
                if _is_rate_limit(e):
                    delay = 30.0 * (2 ** attempt)
                else:
                    delay = 1.0 * (2 ** attempt)
        delay += random.uniform(0, 0.5 * delay)
        await asyncio.sleep(delay)
    return [{'topic': t, 'category': ''} for t in batch]


async def run(unique_topics: list[str], category_names: list[str],
              system_instruction: str, concurrency: int) -> None:
    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key:
        sys.exit('GEMINI_API_KEY not set.')
    client = genai.Client(api_key=api_key)
    category_set = set(category_names)

    response_schema = {
        'type': 'array',
        'items': {'type': 'string', 'enum': category_names},
    }
    config = types.GenerateContentConfig(
        system_instruction=system_instruction,
        temperature=TEMPERATURE,
        response_mime_type='application/json',
        response_schema=response_schema,
    )

    batches = [unique_topics[i:i + BATCH_SIZE]
               for i in range(0, len(unique_topics), BATCH_SIZE)]
    sem = asyncio.Semaphore(concurrency)
    print(f'{len(unique_topics):,} unique topics in {len(batches):,} batches '
          f'of up to {BATCH_SIZE} (concurrency={concurrency})')

    start = time.time()
    buffer: list[dict] = []
    batches_done = 0
    tasks = [asyncio.create_task(
        classify_batch(client, b, category_set, config, sem)) for b in batches]

    for coro in asyncio.as_completed(tasks):
        rows = await coro
        buffer.extend(rows)
        batches_done += 1
        if batches_done % FLUSH_EVERY == 0:
            append_rows(buffer)
            buffer.clear()
            done_topics = batches_done * BATCH_SIZE
            rate = done_topics / (time.time() - start)
            eta_s = (len(unique_topics) - done_topics) / rate if rate else 0
            print(f'  batch {batches_done:,}/{len(batches):,}  '
                  f'~{done_topics:,} topics  rate={rate:.0f}/s  '
                  f'eta={eta_s/60:.1f}m')

    append_rows(buffer)
    elapsed = time.time() - start
    print(f'Done in {elapsed/60:.1f}m. Output -> {OUTPUT_PATH}')


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--limit', type=int, default=None,
                    help='hard cap on unique topics (smoke testing)')
    ap.add_argument('--concurrency', type=int, default=DEFAULT_CONCURRENCY)
    args = ap.parse_args()

    load_env(ROOT / '.env')
    category_names, system_instruction = load_taxonomy()
    print(f'Loaded {len(category_names)} categories from '
          f'{TAXONOMY_PATH.name}')

    df = pd.read_csv(TOPICS_PATH, usecols=['topic'])
    unique_topics = df['topic'].dropna().astype(str).unique().tolist()
    print(f'{len(unique_topics):,} unique topics across '
          f'{len(df):,} speeches')

    done = load_done()
    if done:
        print(f'Resuming: {len(done):,} topics already assigned')
        unique_topics = [t for t in unique_topics if t not in done]
    if args.limit is not None:
        unique_topics = unique_topics[:args.limit]
        print(f'Limit applied: {len(unique_topics):,} topics')
    if not unique_topics:
        print('Nothing to do.')
        return

    asyncio.run(run(unique_topics, category_names,
                    system_instruction, args.concurrency))


if __name__ == '__main__':
    main()
