import os
import pandas as pd
import time
import joblib
from nltk.tokenize import RegexpTokenizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import math
import matplotlib.pyplot as plt
from tqdm import tqdm

os.chdir(r'/Users/mathias/teaching_data_canada/')

### parameters
cluster_groups = 20
ngrams = 2
token = RegexpTokenizer('[a-zA-Z]+')
vectorizer = TfidfVectorizer(lowercase=True,stop_words='english',tokenizer=token.tokenize,ngram_range=(1,ngrams),min_df=5,max_df=0.5)

s = "I like Muffins"
s1 = "I don't like Muffins"
print(token.tokenize(s))
print(token.tokenize(s1))



# Set Paths
#os.chdir(r"C:\Users\HiWi\Desktop\Data Analytics\Lecture 3")
processed_data = "output/speeches_all_mps.csv"
vectorizer_path = "output/vectorizer.sav"
class_path = "output/NLTK_Cluster_"+str(cluster_groups)+".csv"
model_path = "output/NLTK_Model.sav"
cluster_freq_path = "output/Cluster_Frequency.png"
word_freq_path    = "output/Word_Frequency.png"
cluster_path = "output/NLTK_Cluster_"+str(cluster_groups)+".csv"


# Start processing:
total = pd.read_csv(processed_data,delimiter=";")
document = total
beg = time.time()
tfidf = vectorizer.fit(document['speechtext'])
# Save model
joblib.dump(tfidf,vectorizer_path)
text_counts = vectorizer.fit_transform(document['speechtext'])
end = time.time()

print("Duration of transformation: "+str('{:8.2f}'.format(end-beg)+" sec."))
print("We have in total "+str(text_counts.shape[1]) +" words in " +str(text_counts.shape[0]) + " speeches")


# training step:
model = KMeans(n_clusters=cluster_groups,init='k-means++',max_iter=300, n_init=10)
mid2 = time.time()
model.fit(text_counts)
joblib.dump(model,model_path)
end = time.time()
print("Duration of training: "+str('{:8.2f}'.format(end-beg)+" sec."))

order_centroids = model.cluster_centers_.argsort()[:,::-1]
terms = vectorizer.get_feature_names_out()
wlist = []
for ind in order_centroids[0,:10]:
    print('%s' % terms[ind])
    wlist.append(terms[ind])
df = pd.DataFrame(wlist)
for i in range(1,cluster_groups):
    wlist = []
    for ind in order_centroids[i, :10]:
        print('%s' % terms[ind])
        wlist.append(terms[ind])
    df_app = pd.DataFrame(wlist)
    frame = [df,df_app]
    final = pd.concat(frame,axis=1)
    df = final

lst = list(range(0,cluster_groups))
df.columns=lst

df.to_csv(cluster_path, index=False)

### Predicting:
vectorizer = joblib.load(open(vectorizer_path,'rb'))
model = joblib.load(open(model_path,'rb'))

total = pd.read_csv(processed_data,delimiter=";")
lendoc = len(total['speechtext'])
text_counts = vectorizer.transform(total['speechtext'].values.astype('U'))
total["prediction"] = model.predict(text_counts)

outputfile = "output/Prediction.csv"
total.to_csv(outputfile, index=False)

### Plotting Cluster Frequencies over time

########################################################################################################################
########################################################################################################################
# Cluster frequencies across time

print('Produce Plot of Cluster History across Time')

# prepare df for plot
plotfile = total.groupby(["year", "prediction"], as_index=False).count()
group_by = plotfile.groupby('year').sum()
dict_sums = dict(zip(group_by.index, group_by.basepk))
plotfile['year_sum'] = plotfile['year'].apply(lambda x: dict_sums[x])
plotfile['fraction'] = plotfile['basepk']/plotfile['year_sum']

# define plot
if cluster_groups == 40:
    fig, axes = plt.subplots(5, 8, figsize=(50, 25), sharex=True)
if cluster_groups == 20:
    fig, axes = plt.subplots(4, 5, figsize=(30, 15), sharex=True)
if cluster_groups == 10:
    fig, axes = plt.subplots(2, 5, figsize=(30, 15), sharex=True)


axes = axes.flatten()
max_share = plotfile['fraction'].max()
max_share = math.ceil(max_share * 10)/10
min_year = total['year'].min()
max_year = total['year'].max()
plt.setp(axes, xlim=(min_year, max_year), ylim=(0, max_share))

# create 20 subplots
for topic_idx in range(0, cluster_groups, 1):
    years = plotfile[plotfile['prediction'] == topic_idx]['year'].tolist()
    shares = plotfile[plotfile['prediction'] == topic_idx]['fraction'].tolist()

    ax = axes[topic_idx]
    ax.plot(years, shares)
    ax.tick_params(axis="both", which="major", labelsize=10)
    for i in "top right left".split():
        ax.spines[i].set_visible(False)

fig.suptitle('Frequency of Clusters', fontsize=20)
plt.subplots_adjust(top=0.90, bottom=0.05, wspace=0.90, hspace=0.3)
plt.savefig(cluster_freq_path, dpi=300)


### Plotting Cluster Frequencies over time

########################################################################################################################
########################################################################################################################
print('Produce word frequency plot')

clusters = pd.read_csv(cluster_path)

# create empty dataframe
index_list = list(range(0, cluster_groups*2, 1))
index_list = [str(x) for x in index_list]
freqs_df = pd.DataFrame(columns=[index_list])
j = 0
for topic in tqdm(range(0, cluster_groups, 1)):
    speeches = total[total['prediction'] == topic]['speechtext']

    # join all speeches into one string
    string = ' ' + ' '.join(speeches.dropna().astype(str).tolist()) + ' '

    # count the number of occurrences of each word in all speeches
    wordlist = clusters[str(topic)].tolist()
    freqs = []
    for word in wordlist:
        word = " " + word + " "
        freq = string.count(word)
        freqs.append(freq)

    # fill dataframe
    k = j+1
    freqs_df.iloc[:, j] = wordlist
    freqs_df.iloc[:, k] = freqs
    j += 2



index_list = list(range(1, cluster_groups*2, 2))

for i in index_list:
    sum = freqs_df.iloc[:, i].sum()

    freqs_df.iloc[:, i] = freqs_df.iloc[:, i]/sum

# Plot the word frequencies
if cluster_groups == 40:
    fig, axes = plt.subplots(5, 8, figsize=(50, 25), sharex=True)
if cluster_groups == 20:
    fig, axes = plt.subplots(4, 5, figsize=(30, 15), sharex=True)
if cluster_groups == 10:
    fig, axes = plt.subplots(2, 5, figsize=(30, 15), sharex=True)

axes = axes.flatten()
for topic_idx in range(0, cluster_groups, 1):
    top_features = freqs_df.iloc[:, index_list[topic_idx]-1].tolist()
    weights = freqs_df.iloc[:, index_list[topic_idx]].tolist()

    ax = axes[topic_idx]
    ax.barh(top_features, weights, height=0.7)
    ax.invert_yaxis()
    ax.tick_params(axis="both", which="major", labelsize=10)
    for i in "top right left".split():
        ax.spines[i].set_visible(False)
    fig.suptitle('Frequency of the Most Representative Words in each Cluster', fontsize=20)

plt.subplots_adjust(top=0.90, bottom=0.05, wspace=0.90, hspace=0.3)

plt.savefig(word_freq_path, dpi=300)
